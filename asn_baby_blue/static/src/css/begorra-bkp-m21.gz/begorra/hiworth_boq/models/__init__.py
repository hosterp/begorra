import boq
# import re
import property_details
 