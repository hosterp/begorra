{
    'name': 'Hiworth Planning',
    'description': 'Planning',
    'author': 'hiworth',
    'depends': [
        
       
        'hiworth_construction'
    ],
    'data': [
       
        'views/planning_views.xml',
        # 'views/partner_daily_statement_views.xml',
        'views/master_data_estimate_views.xml',
       
    ],
    'installable': True
}